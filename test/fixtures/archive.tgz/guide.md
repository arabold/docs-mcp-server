# Archive Guide

The archive guide explains how the lighthouse keeper trims the lamp wick.
